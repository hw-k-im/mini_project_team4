package com.lgcns.studify.user.enums;

public enum UserStatus {
    ACTIVE,
    INACTIVE,
    PENDING,
    BANNED
}